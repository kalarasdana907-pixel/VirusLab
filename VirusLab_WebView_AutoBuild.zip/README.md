# VirusLab WebView build projects

Two separate Android projects:
- VirusLabAgent
- VirusLabControl

Each app displays a local WebView interface. This is a safe UI prototype:
- Agent displays a temporary six-digit demo code.
- Control validates the six-digit code format locally.
- No network connection, remote control, camera, microphone, location, or screen capture is implemented.

## Build APKs automatically
1. Upload the contents of this folder to a new GitHub repository.
2. Open the repository's **Actions** tab.
3. Run **Build VirusLab APKs** (or push to the main branch).
4. Download the `VirusLab-debug-apks` artifact from the completed workflow.

The outputs are debug APKs for testing, not Play Store releases.
